import './SubmitProject.css'
function SubmitProject() {
    return (
        <>
            <button className="submit-project" onClick={() => window.open("https://docs.google.com/forms/d/1he_x7bZtDTfUTdt8y2fdJF4gIFjMp2kxyy-7rD4ei9w/viewform?edit_requested=true")}>Enviar Projeto</button>
        </>
    )
}

export default SubmitProject;